import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'

/**
 * Minimal login handler for development/demo.
 * - Uses an in-memory user store (FOR DEMO ONLY).
 * - Returns a signed JWT when credentials match.
 *
 * Replace with a proper data store and hashed password check (bcrypt) in production.
 */

type User = { id: number; email: string; password: string; name: string }

// Demo users (plaintext password for convenience)
// email: test@example.com
// password: password123
const users: User[] = [
  { id: 1, email: 'test@example.com', password: 'password123', name: 'Test User' }
]

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me'

export async function loginHandler(req: Request, res: Response) {
  const { email, password } = req.body as { email?: string; password?: string }
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' })
  }

  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase())
  // For demo we compare plaintext; replace with bcrypt.compare in production
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'Invalid email or password' })
  }

  const token = jwt.sign(
    { sub: user.id, email: user.email, name: user.name },
    JWT_SECRET,
    { expiresIn: '2h' }
  )

  return res.json({
    token,
    user: { id: user.id, email: user.email, name: user.name }
  })
}