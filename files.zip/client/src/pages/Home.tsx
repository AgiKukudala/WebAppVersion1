import React from 'react'

export default function Home() {
  return (
    <section>
      <h2>Home</h2>
      <p>This is the main front page. Keep the content that matters here.</p>
    </section>
  )
}