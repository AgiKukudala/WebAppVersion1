import React from 'react'

export default function Projects() {
  return (
    <section>
      <h2>Projects</h2>
      <ul>
        <li>Project A — short description</li>
        <li>Project B — short description</li>
      </ul>
    </section>
  )
}