import React from 'react'

export default function About() {
  return (
    <section>
      <h2>About</h2>
      <p>Short about text. This is a valuable front-end page to keep.</p>
    </section>
  )
}