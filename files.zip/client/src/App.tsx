import React, { useState } from 'react'
import Home from './pages/Home'
import Projects from './pages/Projects'
import About from './pages/About'
import Login from './pages/Login'

type Page = 'home' | 'projects' | 'about' | 'login'

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [user, setUser] = useState<{ name: string } | null>(null)

  function onLogin(userObj: { name: string }) {
    setUser(userObj)
    setPage('home')
  }

  return (
    <div className="app">
      <header className="header">
        <h1 className="brand">My Site</h1>
        <nav className="nav">
          <button onClick={() => setPage('home')}>Home</button>
          <button onClick={() => setPage('projects')}>Projects</button>
          <button onClick={() => setPage('about')}>About</button>
          {user ? (
            <span className="welcome">Welcome, {user.name}</span>
          ) : (
            <button onClick={() => setPage('login')}>Login</button>
          )}
        </nav>
      </header>

      <main className="main">
        {page === 'home' && <Home />}
        {page === 'projects' && <Projects />}
        {page === 'about' && <About />}
        {page === 'login' && <Login onLogin={onLogin} />}
      </main>

      <footer className="footer">© {new Date().getFullYear()}</footer>
    </div>
  )
}