```markdown
# WebAppVersion1 — Minimal Frontend + Login Backend

This repository is a minimal starter you can open in VS Code. It contains:
- client/: React + TypeScript frontend (Vite) with pages: Home, Projects, About, Login.
- server/: Minimal Express + TypeScript backend with a login endpoint (`POST /api/auth/login`) that returns a JWT.

Quick start
1. Open the repository folder in VS Code.
2. Install dependencies:
   - Client:
     cd client
     npm install
   - Server:
     cd server
     npm install
3. Start the server:
   cd server
   npm run dev
   (default: http://localhost:4000)
4. Start the client:
   cd client
   npm run dev
   (Vite usually serves at http://localhost:5173)
5. Login credentials (development demo):
   - email: test@example.com
   - password: password123

Notes
- Server uses an in-memory user store for demo. Replace with a DB and bcrypt in production.
- Create `server/.env` from `.env.example` and set a strong `JWT_SECRET` for production.
```